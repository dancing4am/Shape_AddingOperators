var searchData=
[
  ['setcolour',['SetColour',['../class_shape.html#adb4ab6ec7a6354888891b123f39ddc45',1,'Shape']]],
  ['setname',['SetName',['../class_shape.html#a781c96d15c3f04f51b29984da64701e8',1,'Shape']]],
  ['setradius',['SetRadius',['../class_circle.html#a9c2a399ea6ce0ba7e21ce44db3ad5f80',1,'Circle']]],
  ['setsidelength',['SetSideLength',['../class_square.html#a267a4231ae17304fafe9ba31c96ecd9b',1,'Square']]],
  ['shape',['Shape',['../class_shape.html',1,'Shape'],['../class_shape.html#a7385befa194396e0934b56dfa8c0853d',1,'Shape::Shape(string newName, string newColour)'],['../class_shape.html#a2c81e227edd2803a084c65c75e4ffd5b',1,'Shape::Shape(void)']]],
  ['show',['Show',['../class_circle.html#a9ade44170d48efc91d3c35e8be4e4b5a',1,'Circle::Show()'],['../class_shape.html#ab7020f0c5fdeacd75cce08a55e7b2329',1,'Shape::Show()'],['../class_square.html#a2a7e3a73cfbe9045d8a27dd8f738fda9',1,'Square::Show()']]],
  ['square',['Square',['../class_square.html',1,'Square'],['../class_shape.html#af85512b9e7eebc0019fb55ad4fb4c95d',1,'Shape::SQUARE()'],['../class_square.html#aab65c26f36597ea29e74d318ea1505b3',1,'Square::Square(string colour, float sideLength)'],['../class_square.html#a7411e99cc5900fedb7d2f8e3eb74540a',1,'Square::Square(void)']]]
];
