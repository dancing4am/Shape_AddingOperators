var searchData=
[
  ['square',['SQUARE',['../class_shape.html#af85512b9e7eebc0019fb55ad4fb4c95d',1,'Shape']]]
];
