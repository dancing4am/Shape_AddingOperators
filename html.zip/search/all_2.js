var searchData=
[
  ['getcolour',['GetColour',['../class_shape.html#a88554b555eae9ec283a624ef0e8d8305',1,'Shape']]],
  ['getname',['GetName',['../class_shape.html#a8c655808e4fdc91b10c5dff75ab5038e',1,'Shape']]],
  ['getradius',['GetRadius',['../class_circle.html#a780cdaca9230a6478da4b36ab19d8646',1,'Circle']]],
  ['getsidelength',['GetSideLength',['../class_square.html#aa42dc1ab0a35471ae62e34a8f1c981af',1,'Square']]]
];
